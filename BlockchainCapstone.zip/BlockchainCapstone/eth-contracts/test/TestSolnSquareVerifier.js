
var solnSquareContract = artifacts.require('SolnSquareVerifier');
var verifierContract = artifacts.require("verifier");
var json = require("./proof.json");


contract('Square_verifier', accounts => {

    const account_one = accounts[0];
    const account_two = accounts[1];
    const account_three = accounts[2];
    const account_four = accounts[3];
    const symbol = "TKN";
    const name = "House_Token";
    const uri = "https://s3-us-west-2.amazonaws.com/udacity-blockchain/capstone/";



    describe('Test if a new solution can be added for contract - SolnSquareVerifier', function () {
		addContract =true;
        beforeEach(async function () {
            const verifier = await verifierContract.new({from: account_one});
            this.contract = await solnSquareContract.new(verifier.address, name, symbol, {from: account_one});

        });

       it('should test if a new solution can be added for contract SolnSquareVerifier', async function () { 
		let cont = true;
		try{
		  await this.contract.addSolution(json.proof.A,json.proof.A_p,json.proof.B,json.proof.B_p,json.proof.C,json.proof.C_p,json.proof.H,json.proof.K,json.input,{from:account_two});
		   }
		 catch(e){
			   addContract = false
			 }
		assert.equal(addContract, true, "Solution exists already","Was able to make two identical solutions");
			});

  });

    describe('Test if an ERC721 token can be minted for contract - SolnSquareVerifier', function () {
        beforeEach(async function () {
          const verifier = await verifierContract.new({from: account_one});
          this.contract = await solnSquareContract.new(verifier.address, name, symbol, {from: account_one});
        })

        it('mintERC721', async function () {

          let result = await this.contract.addSolution(json.proof.A,json.proof.A_p,json.proof.B,json.proof.B_p,json.proof.C,json.proof.C_p,json.proof.H,json.proof.K,json.input,{from:account_one});
          assert.equal(result.logs[0].args[1], account_one,"Solution-address doesn't match senders adddress");
          await this.contract.mintNewNFT(json.input[0],json.input[1],account_three,{from:account_one});
          let balance = await this.contract.balanceOf(account_three);
          assert.equal(parseInt(balance), 1, "Incorrect token balance");

          let uri = await this.contract.tokenURI(0,{from:account_one});
          assert.equal(uri, "https://s3-us-west-2.amazonaws.com/udacity-blockchain/capstone/0"," Incorrect uri");


        });
    });

})
